## Summary

Describe what changed and why.

## Validation

- [ ] Application builds locally
- [ ] Database changes are documented
- [ ] Authentication and role permissions were checked
- [ ] No secrets or personal data were committed
- [ ] UI was checked on desktop and mobile

## Screenshots

Add screenshots for visible changes.
