import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import Sidebar from '@/components/Sidebar';
import AdminVerificationButtons from '@/components/AdminVerificationButtons';

export default async function AdminPage(){
  const user=await currentUser(); if(!user)redirect('/auth/login'); if(user.role!=='ADMIN')redirect('/dashboard');
  const [users,companies,rfqs,quotes]=await Promise.all([db.user.count(),db.company.findMany({include:{owner:true,_count:{select:{products:true}}},orderBy:{createdAt:'desc'}}),db.rfq.count(),db.quote.count()]);
  return <main className="container"><div className="layout"><Sidebar role={user.role}/><section><h1>Administration</h1><div className="stats"><div className="stat"><b>{users}</b><span className="muted">Users</span></div><div className="stat"><b>{companies.length}</b><span className="muted">Suppliers</span></div><div className="stat"><b>{rfqs}</b><span className="muted">RFQs</span></div><div className="stat"><b>{quotes}</b><span className="muted">Quotes</span></div></div><h2 className="top-gap">Supplier verification</h2><div className="table-wrap"><table className="table"><thead><tr><th>Company</th><th>Owner</th><th>Location</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead><tbody>{companies.map((c:any)=><tr key={c.id}><td><b>{c.name}</b><div className="muted">{c.gstin||'GSTIN not supplied'}</div></td><td>{c.owner.email}</td><td>{c.city}, {c.state}</td><td>{c._count.products}</td><td><span className={`badge status-${c.verification.toLowerCase()}`}>{c.verification}</span></td><td><AdminVerificationButtons id={c.id}/></td></tr>)}</tbody></table></div></section></div></main>;
}
