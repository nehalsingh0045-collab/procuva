import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { z } from 'zod';

const schema = z.object({ verification: z.enum(['PENDING', 'VERIFIED', 'REJECTED']) });
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    if (user.role !== 'ADMIN') return NextResponse.json({ error: 'Admin account required' }, { status: 403 });
    const body = schema.parse(await req.json());
    const { id } = await params;
    await db.company.update({ where: { id }, data: { verification: body.verification } });
    return NextResponse.json({ ok: true });
  } catch (error: any) {
    return NextResponse.json({ error: error?.issues?.[0]?.message || 'Unable to update verification' }, { status: 400 });
  }
}
