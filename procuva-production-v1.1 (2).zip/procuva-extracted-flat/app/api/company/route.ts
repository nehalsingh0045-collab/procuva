import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { companySchema } from '@/lib/validators';

export async function PATCH(req: Request) {
  try {
    const user = await requireUser();
    if (user.role !== 'SUPPLIER') return NextResponse.json({ error: 'Supplier account required' }, { status: 403 });
    const body = companySchema.parse(await req.json());
    await db.company.update({ where: { ownerId: user.id }, data: { ...body, verification: 'PENDING' } });
    return NextResponse.json({ ok: true });
  } catch (error: any) {
    return NextResponse.json({ error: error?.issues?.[0]?.message || 'Unable to update company' }, { status: 400 });
  }
}
