import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
export async function GET(){try{await db.user.count();return NextResponse.json({status:'ok',service:'procuva'});}catch{return NextResponse.json({status:'error'},{status:503});}}
