import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireUser } from '@/lib/auth';

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    if (user.role !== 'SUPPLIER') return NextResponse.json({ error: 'Supplier account required' }, { status: 403 });
    const company = await db.company.findUnique({ where: { ownerId: user.id } });
    const { id } = await params;
    const product = await db.product.findUnique({ where: { id } });
    if (!company || !product || product.companyId !== company.id) return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    await db.product.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: 'Unable to delete product' }, { status: 400 });
  }
}
