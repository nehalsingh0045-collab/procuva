import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { productSchema } from '@/lib/validators';

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    if (user.role !== 'SUPPLIER') return NextResponse.json({ error: 'Supplier account required' }, { status: 403 });
    const company = await db.company.findUnique({ where: { ownerId: user.id } });
    if (!company) return NextResponse.json({ error: 'Supplier company profile not found' }, { status: 404 });
    const body = productSchema.parse(await req.json());
    const product = await db.product.create({ data: { ...body, companyId: company.id, indicativePrice: body.indicativePrice ?? null } });
    return NextResponse.json({ ok: true, id: product.id });
  } catch (error: any) {
    return NextResponse.json({ error: error.message === 'UNAUTHENTICATED' ? 'Please log in' : error?.issues?.[0]?.message || 'Unable to add product' }, { status: 400 });
  }
}
