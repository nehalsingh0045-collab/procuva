import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { z } from 'zod';

const schema = z.object({ status: z.enum(['SHORTLISTED', 'ACCEPTED', 'REJECTED']) });
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    if (user.role !== 'BUYER' && user.role !== 'ADMIN') return NextResponse.json({ error: 'Buyer account required' }, { status: 403 });
    const { id } = await params;
    const quote = await db.quote.findUnique({ where: { id }, include: { rfq: true } });
    if (!quote || (user.role === 'BUYER' && quote.rfq.buyerId !== user.id)) return NextResponse.json({ error: 'Quote not found' }, { status: 404 });
    const body = schema.parse(await req.json());
    await db.$transaction(async (tx:any) => {
      if (body.status === 'ACCEPTED') {
        await tx.quote.updateMany({ where: { rfqId: quote.rfqId, id: { not: id } }, data: { status: 'REJECTED' } });
        await tx.rfq.update({ where: { id: quote.rfqId }, data: { status: 'AWARDED' } });
      }
      await tx.quote.update({ where: { id }, data: { status: body.status } });
    });
    return NextResponse.json({ ok: true });
  } catch (error: any) {
    return NextResponse.json({ error: error?.issues?.[0]?.message || 'Unable to update quote' }, { status: 400 });
  }
}
