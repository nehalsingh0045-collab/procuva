import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { z } from 'zod';

const schema = z.object({ status: z.enum(['OPEN', 'CLOSED', 'CANCELLED']) });
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await params;
    const rfq = await db.rfq.findUnique({ where: { id } });
    if (!rfq || (user.role !== 'ADMIN' && rfq.buyerId !== user.id)) return NextResponse.json({ error: 'RFQ not found' }, { status: 404 });
    const body = schema.parse(await req.json());
    await db.rfq.update({ where: { id }, data: { status: body.status } });
    return NextResponse.json({ ok: true });
  } catch (error: any) {
    return NextResponse.json({ error: error?.issues?.[0]?.message || 'Unable to update RFQ' }, { status: 400 });
  }
}
