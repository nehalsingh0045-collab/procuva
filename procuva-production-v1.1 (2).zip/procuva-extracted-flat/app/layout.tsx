import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';

export const metadata: Metadata = {
  title: { default: 'Procuva', template: '%s | Procuva' },
  description: 'AI-assisted industrial procurement marketplace for buyers and verified suppliers.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><Header />{children}<footer className="footer"><div className="container">© {new Date().getFullYear()} Procuva · Industrial procurement, simplified.</div></footer></body></html>;
}
