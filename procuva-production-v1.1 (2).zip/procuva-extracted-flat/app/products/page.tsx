import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import Sidebar from '@/components/Sidebar';
import ProductForm from '@/components/ProductForm';
import DeleteProductButton from '@/components/DeleteProductButton';

export default async function ProductsPage() {
  const user = await currentUser(); if (!user) redirect('/auth/login'); if (user.role !== 'SUPPLIER' || !user.company) redirect('/dashboard');
  const [products, categories] = await Promise.all([
    db.product.findMany({ where: { companyId: user.company.id }, include: { category: true }, orderBy: { createdAt: 'desc' } }),
    db.category.findMany({ orderBy: { name: 'asc' } })
  ]);
  return <main className="container"><div className="layout"><Sidebar role={user.role}/><section><h1>Product catalogue</h1><p className="muted">Maintain the products buyers can discover on your supplier profile.</p><ProductForm categories={categories}/><div className="table-wrap"><table className="table"><thead><tr><th>Product</th><th>Category</th><th>MOQ</th><th>Price</th><th></th></tr></thead><tbody>{products.map((x:any)=><tr key={x.id}><td><b>{x.name}</b><div className="muted">{x.brand||'Unbranded'}</div></td><td>{x.category.name}</td><td>{x.minOrderQty} {x.unit}</td><td>{x.indicativePrice ? `₹${Number(x.indicativePrice).toLocaleString('en-IN')}` : 'On request'}</td><td><DeleteProductButton id={x.id}/></td></tr>)}</tbody></table></div>{products.length===0&&<div className="notice">No products added yet.</div>}</section></div></main>;
}
