import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import Sidebar from '@/components/Sidebar';
import CompanyForm from '@/components/CompanyForm';
export default async function ProfilePage(){const user=await currentUser();if(!user)redirect('/auth/login');return <main className="container"><div className="layout"><Sidebar role={user.role}/><section><h1>Profile</h1><div className="card"><h3>{user.name}</h3><p>{user.email}</p><span className="badge">{user.role}</span></div>{user.role==='SUPPLIER'&&user.company&&<CompanyForm company={{name:user.company.name,gstin:user.company.gstin||'',description:user.company.description||'',address:user.company.address||'',city:user.company.city,state:user.company.state,pincode:user.company.pincode||'',website:user.company.website||''}}/>}</section></div></main>}
