import { notFound, redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import Sidebar from '@/components/Sidebar';
import QuoteActions from '@/components/QuoteActions';
import RfqActions from '@/components/RfqActions';

export default async function RfqDetail({params}:{params:Promise<{id:string}>}){
  const user=await currentUser(); if(!user)redirect('/auth/login'); const {id}=await params;
  const rfq=await db.rfq.findUnique({where:{id},include:{category:true,quotes:{include:{supplier:{include:{company:true}}},orderBy:{unitPrice:'asc'}}}}); if(!rfq)notFound();
  const canView=user.role==='ADMIN'||rfq.buyerId===user.id; if(!canView)redirect(`/marketplace/${id}`);
  return <main className="container"><div className="layout"><Sidebar role={user.role}/><section><div className="page-heading"><div><span className="badge">{rfq.status}</span><h1>{rfq.title}</h1><p className="muted">{rfq.category.name} · {rfq.quantity} {rfq.unit} · Deliver to {rfq.deliveryCity}, {rfq.deliveryState}</p></div><RfqActions id={rfq.id} status={rfq.status}/></div><div className="card"><h3>Specification</h3><p className="preline">{rfq.description}</p>{rfq.brandPreference&&<p><b>Preferred brand:</b> {rfq.brandPreference}</p>}{rfq.budget&&<p><b>Budget:</b> ₹{Number(rfq.budget).toLocaleString('en-IN')}</p>}</div><h2 className="top-gap">Received quotations ({rfq.quotes.length})</h2><div className="quote-grid">{rfq.quotes.map((q:any)=>{const subtotal=Number(q.unitPrice)*rfq.quantity;const tax=subtotal*Number(q.taxPercent)/100;const total=subtotal+tax+Number(q.shippingCost);return <article className={`card quote-card ${q.status==='ACCEPTED'?'accepted':''}`} key={q.id}><div className="page-heading"><div><span className="badge">{q.status}</span><h3>{q.supplier.company?.name||q.supplier.name}</h3><p className="muted">{q.supplier.company?.city}, {q.supplier.company?.state}</p></div><b className="price">₹{total.toLocaleString('en-IN',{maximumFractionDigits:2})}</b></div><div className="quote-breakdown"><span>Unit price <b>₹{Number(q.unitPrice).toLocaleString('en-IN')}</b></span><span>Tax <b>{Number(q.taxPercent)}%</b></span><span>Shipping <b>₹{Number(q.shippingCost).toLocaleString('en-IN')}</b></span><span>Delivery <b>{q.deliveryDays} days</b></span></div>{q.remarks&&<p>{q.remarks}</p>}<QuoteActions id={q.id} status={q.status}/></article>})}</div>{rfq.quotes.length===0&&<div className="notice">No quotations received yet.</div>}</section></div></main>;
}
