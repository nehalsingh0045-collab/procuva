'use client';
import { useRouter } from 'next/navigation';
export default function DeleteProductButton({ id }: { id: string }) { const router = useRouter(); return <button className="link-danger" onClick={async()=>{if(!confirm('Delete this product?'))return;await fetch(`/api/products/${id}`,{method:'DELETE'});router.refresh();}}>Delete</button> }
