import Link from 'next/link';
import { getSession } from '@/lib/auth';

export default async function Header() {
  const session = await getSession();
  return <header className="nav"><div className="container navin">
    <Link href="/" className="brand">Pro<span>cuva</span></Link>
    <nav className="links">
      <Link href="/marketplace">Marketplace</Link>
      <Link href="/suppliers">Suppliers</Link>
      {session ? <>
        <Link href="/dashboard">Dashboard</Link>
        <form action="/api/auth/logout" method="post"><button className="btn secondary" type="submit">Log out</button></form>
      </> : <>
        <Link href="/auth/login">Log in</Link>
        <Link href="/auth/register" className="btn">Join Procuva</Link>
      </>}
    </nav>
  </div></header>;
}
