'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ProductForm({ categories }: { categories: { id: string; name: string }[] }) {
  const router = useRouter(); const [message, setMessage] = useState('');
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setMessage('');
    const res = await fetch('/api/products', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(e.currentTarget))) });
    const json = await res.json(); if (!res.ok) return setMessage(json.error);
    e.currentTarget.reset(); setMessage('Product added.'); router.refresh();
  }
  return <form className="card form" onSubmit={submit}><h3>Add a product</h3>{message && <div className={message === 'Product added.' ? 'notice' : 'notice error'}>{message}</div>}
    <div className="field"><label>Product name</label><input className="input" name="name" required /></div>
    <div className="field"><label>Category</label><select name="categoryId" required><option value="">Choose category</option>{categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
    <div className="form-row"><div className="field"><label>Brand</label><input className="input" name="brand" /></div><div className="field"><label>Unit</label><input className="input" name="unit" defaultValue="piece" /></div></div>
    <div className="form-row"><div className="field"><label>Minimum order</label><input className="input" type="number" name="minOrderQty" min="1" defaultValue="1" /></div><div className="field"><label>Indicative price (₹)</label><input className="input" type="number" step="0.01" name="indicativePrice" /></div></div>
    <div className="field"><label>Description</label><textarea name="description" rows={3} /></div><button className="btn">Add product</button>
  </form>;
}
