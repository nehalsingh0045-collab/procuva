import { cookies } from 'next/headers';
import { SignJWT, jwtVerify } from 'jose';
import { db } from './db';
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || 'development-only-secret-change-me');
export type SessionUser = { id: string; name: string; email: string; role: 'BUYER'|'SUPPLIER'|'ADMIN' };
export async function createSession(user: SessionUser) {
  const token = await new SignJWT(user).setProtectedHeader({ alg: 'HS256' }).setIssuedAt().setExpirationTime('7d').sign(secret);
  (await cookies()).set('procuva_session', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60*60*24*7 });
}
export async function destroySession(){ (await cookies()).delete('procuva_session'); }
export async function getSession(): Promise<SessionUser|null> {
  const token = (await cookies()).get('procuva_session')?.value;
  if (!token) return null;
  try { const { payload } = await jwtVerify(token, secret); return payload as unknown as SessionUser; } catch { return null; }
}
export async function requireUser(){ const s=await getSession(); if(!s) throw new Error('UNAUTHENTICATED'); return s; }
export async function currentUser(){ const s=await getSession(); return s ? db.user.findUnique({where:{id:s.id},include:{company:true}}) : null; }
