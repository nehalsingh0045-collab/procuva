import { z } from 'zod';

const optionalText = z.preprocess(v => v === '' ? undefined : v, z.string().optional());
const optionalNumber = z.preprocess(v => v === '' || v === undefined ? undefined : Number(v), z.number().positive().optional());

export const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160),
  password: z.string().min(8).max(128),
  role: z.enum(['BUYER', 'SUPPLIER']),
  phone: optionalText,
  companyName: optionalText,
  city: optionalText,
  state: optionalText,
});

export const rfqSchema = z.object({
  title: z.string().trim().min(4).max(160),
  description: z.string().trim().min(10).max(4000),
  categoryId: z.string().min(1),
  quantity: z.coerce.number().int().positive().max(10_000_000),
  unit: z.string().trim().min(1).max(30),
  brandPreference: optionalText,
  deliveryCity: z.string().trim().min(2).max(80),
  deliveryState: z.string().trim().min(2).max(80),
  neededBy: optionalText,
  budget: optionalNumber,
});

export const quoteSchema = z.object({
  rfqId: z.string().min(1),
  unitPrice: z.coerce.number().positive(),
  taxPercent: z.coerce.number().min(0).max(100).default(18),
  deliveryDays: z.coerce.number().int().positive().max(3650),
  shippingCost: z.coerce.number().min(0).default(0),
  remarks: optionalText,
  validityDays: z.coerce.number().int().positive().max(365).default(7),
});

export const productSchema = z.object({
  categoryId: z.string().min(1),
  name: z.string().trim().min(2).max(160),
  brand: optionalText,
  description: optionalText,
  unit: z.string().trim().min(1).max(30).default('piece'),
  minOrderQty: z.coerce.number().int().positive().default(1),
  indicativePrice: optionalNumber,
});

export const companySchema = z.object({
  name: z.string().trim().min(2).max(160),
  gstin: optionalText,
  description: optionalText,
  address: optionalText,
  city: z.string().trim().min(2).max(80),
  state: z.string().trim().min(2).max(80),
  pincode: optionalText,
  website: optionalText,
});
