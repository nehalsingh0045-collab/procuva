$ErrorActionPreference = "Stop"

if (-not (Test-Path ".env")) {
  Copy-Item ".env.example" ".env"
  Write-Host "Created .env from .env.example"
}

docker compose up -d db
npm install
npx prisma db push
npm run db:seed

Write-Host "Setup complete. Run: npm run dev"
