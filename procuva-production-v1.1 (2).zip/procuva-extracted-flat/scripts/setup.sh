#!/usr/bin/env bash
set -euo pipefail

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi

docker compose up -d db
npm install
npx prisma db push
npm run db:seed

echo "Setup complete. Run: npm run dev"
